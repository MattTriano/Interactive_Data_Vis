var pie3_value_csv = `value
4905
5601
2981
3609
1103
2170`