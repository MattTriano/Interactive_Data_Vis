var pie1_value_csv = `value
2
4
7
1
9
3`
