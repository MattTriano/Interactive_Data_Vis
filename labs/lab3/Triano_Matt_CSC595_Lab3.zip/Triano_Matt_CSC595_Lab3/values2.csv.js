var pie2_value_csv = `value
26
48
37
17
9
34`
